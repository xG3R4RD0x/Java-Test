package visitor;

public interface Produkt {

public void accept(visitor v); 

}
