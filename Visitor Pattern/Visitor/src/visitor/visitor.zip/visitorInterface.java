package visitor;

public interface visitorInterface {
    
    public void visitPackage(Package p);
    public void visitItem(Item i);
    


}
