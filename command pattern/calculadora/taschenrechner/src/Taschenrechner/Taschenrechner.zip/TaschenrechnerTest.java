package Taschenrechner;

public class TaschenrechnerTest {
	
	public static void main(String[] args) {
		//Taschenrechner t = new Taschenrechner();
		calculator c= new calculator();
		calculatorview tv = new calculatorview(c);
	}

}
