package Taschenrechner;

public interface command {
    
    public abstract void execute();

}
